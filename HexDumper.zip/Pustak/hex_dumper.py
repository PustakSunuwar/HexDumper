class Hex_Dumper():
    def __init__(self):  
        self.get_file()
        self.method = 0
        self.dump_dict = {}
        self.dump_dict["b"] = self.to_binary 
        self.dump_dict["d"] = self.to_decimal
        self.dump_dict["o"] = self.to_octal
        self.dump_dict["h"] = self.to_hex
        self.dump_dict["a"] = self.to_ascii
        self.dump_dict["e"] = self.esc_char
#         self.dump_dict["all"] = self.to_binary, self.to_decimal,self.to_octal, self.to_hex, self.to_ascii, self.esc_char
        self.dump_dict["n"] = self.get_file
        self.dump_dict["q"] = self.quit
    def test(self):
        while True:
            print("Enter b for binary representation")
            print("Enter d for decimal representation")
            print("Enter o for octal representation")
            print("Enter h for hexadecimal representation")
            print("Enter a for ascii representation")
            print("Enter e for escape characters")
#             print("Enter 'all' to print every format")
            print("Enter n to open a new file")
            print("Enter q to quit \n")
            letter = input("Enter a letter: ")
            value = self.dump_dict.get(letter, None)
            if value is None:
                print("Unrecognized letter")
            else:
#                 for i in value:
                value()
                if self.method is None:
                    break
    def get_file(self):
        self.filename = input("Enter the name of the file: ") 
    def quit(self):
        self.method = None
    def to_binary(self):
        with open (self.filename, 'rb') as handle:
            allbytes = handle.read()  
            print("Binary representation:")
            for one_byte in allbytes:
                bin_val = format(one_byte,'b')
                print("%4s " % (bin_val), end=" ")
            print()
    def to_decimal(self):
        with open (self.filename, 'rb') as handle:
            allbytes = handle.read()  
            print("Decimal representation:")           
            for one_byte in allbytes:
                print("%4d " % (one_byte), end=" ")
            print()
    def to_octal(self):
        with open (self.filename, 'rb') as handle:
            allbytes = handle.read()  
            print("Octal representation:")
            for one_byte in allbytes:
                oct_val = format(one_byte,'o')
                print("%4s " % (oct_val), end=" ")  
            print()
    def to_hex(self):
        with open (self.filename, 'rb') as handle:
            allbytes = handle.read()  
            print("Hexadecimal representation:")
            for one_byte in allbytes:
                hex_val = format(one_byte,'X')
                print("%4s " % (hex_val), end=" ")
            print()
            
    def to_ascii(self):
        with open (self.filename, 'rb') as handle:
            allbytes = handle.read() 
            print("ASCII represemtation:")
            for one_byte in allbytes:
                asc_chr = chr(one_byte)
                if asc_chr.isprintable():
                    print("%4s " % (asc_chr), end='')
                else:
                    print("*", end="")
            print()
    def esc_char(self):
        with open (self.filename, 'rb') as handle:
            allbytes = handle.read() 
            print("Non printable bytes:")
            for one_byte in allbytes:
                asc_chr = chr(one_byte)
                if asc_chr.isprintable():
                        print("*", end='')
                else:
                    esc_chr = repr(asc_chr)
                    print("%4s " % (esc_chr), end='')
            print()
if __name__ == "__main__":
    hd=Hex_Dumper()
    hd.test()
